package uk.ac.hw.macs.CompanyDatabase;


import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class OwnQueries extends JFrame 
                      implements ActionListener
{   
  	JTextArea outputArea;
  	QueryTable tableResults;
	Connection con;
	final static int NUM_BUTTONS = 14;
	JButton queryButton[] = new JButton[NUM_BUTTONS];
  
  	/////////////////////////////////////////////////////////////////
  	//Constructor sets up frame with 
  	//	an area for SQL entry 
  	//	a table for results
  	public OwnQueries(Connection conn) 
	{
		//Initialise frame
	  	super("SQL Query");
	   	addWindowListener(new WindowAdapter()
							{public void windowClosing (WindowEvent e)	
								{dispose();}});
	   	setSize(650, 600);
	   	createButtons();	          
	   	createTableAndTextArea();
	   	
	   	//connect to database and prepare some statements
		con = conn;	   	
	}
  	
  	
  	//places table in center and text area in south 
  	public void createTableAndTextArea() {
	    
	    //Set QueryTable in scrollpane in centre of layout
	   	//Results from the query will be stored here
	    tableResults = new QueryTable ();
	    JTable table = new JTable(tableResults);
	    JScrollPane scrollpane = new JScrollPane(table);
	    getContentPane().add(scrollpane, BorderLayout.CENTER);
	    
	    //Add text area
	    outputArea = new JTextArea("",8,50); 
	    JScrollPane scroll = new JScrollPane(outputArea);
	   	add(scroll, BorderLayout.SOUTH);  
	}
  	
  	public void createButtons() {
	    //Create upper panels for label, text area and buttons
	    JPanel p1 = new JPanel();
	   	p1.setLayout(new GridLayout (NUM_BUTTONS,1));
	   	
	   	//++//++//++//++//++//++//++//++//++//++//++//++//++//++
	   	//change the button texts in this section
	   	queryButton[0] = 	new JButton("Employees that have not worked on a radio campaign");
	   	queryButton[1] = 	new JButton("Each client's list of different advert types they have been commissioned for");
	   	queryButton[2] = 	new JButton("Employee that has logged the most hours across all campaigns");  	
	   	queryButton[3] = 	new JButton("Total staff time cost for specific campaign");  	
	   	queryButton[4] = 	new JButton("Average cost of all campaigns for clients who have clientID beginning with 1");
	   	queryButton[5] = 	new JButton("Earnings per hour worked on each campaign");  	
	   	queryButton[6] = 	new JButton("Employees that haven't worked more than 10 hours on a project");
	   	queryButton[7] = 	new JButton("List of employeeIDs, and their first and last names");
	   	queryButton[8] = 	new JButton("All middle managers");
	   	queryButton[9] = 	new JButton("Adverts that have a target demographic that aplies to 16 - 30 year olds");
	   	queryButton[10] = 	new JButton("Employees that worked on each campaign, with the cost of each campaign");
	   	queryButton[11] = 	new JButton("Campaigns which have a TV or Radio advert that runs over 40 seconds");
	   	queryButton[12] = 	new JButton("Number of employees involved in an advert in each region");
	   	queryButton[13] = 	new JButton("Shows campaigns that do not have a web advert");

	   	//++//++//++//++//++//++//++//++//++//++//++//++//++//++
	   
	   	//add buttons to panel - don't change this
	   	for (int count = 0; count < NUM_BUTTONS; count++) {
	   		queryButton[count].addActionListener(this);
	   		p1.add(queryButton[count]);
	   	}	   	
	   	add(p1, BorderLayout.NORTH);
  	}
  
  	/////////////////////////////////////////////////////////////////
  	//Handles all actions from the GUI
  	public void actionPerformed(ActionEvent e) 
  	{	
  		if (e.getSource() == queryButton[0]) 
  			process0();
  		else if (e.getSource() == queryButton[1]) 
  			process1();
  		else if (e.getSource() == queryButton[2] ) 
  			process2();
  		else if (e.getSource() == queryButton[3] ) 
  			process3();
  		else if (e.getSource() == queryButton[4] ) 
  			process4();
  		else if (e.getSource() == queryButton[5] ) 
  			process5();
  		else if (e.getSource() == queryButton[6] ) 
  			process6();
  		else if (e.getSource() == queryButton[7] ) 
  			process7();
  		else if (e.getSource() == queryButton[8] ) 
  			process8();
  		else if (e.getSource() == queryButton[9] ) 
  			process9();
  		else if (e.getSource() == queryButton[10] ) 
  			process10();
  		else if (e.getSource() == queryButton[11] ) 
  			process11();
  		else if (e.getSource() == queryButton[12] ) 
  			process12();
  		else if (e.getSource() == queryButton[13] ) 
  			process13();

  	}
  
  	//selects some data and puts it into the  table
	public void process0() {     
		String query = 	"SELECT DISTINCT Employee.employeeID, PersonalInfo.firstName, PersonalInfo.secondName " + 
						"FROM PersonalInfo INNER JOIN Employee ON Employee.personID = PersonalInfo.personID " +
						"WHERE Employee.employeeID NOT IN (SELECT DISTINCT Employee.employeeID " + 
						"FROM Employee INNER JOIN WorkDone ON WorkDone.employeeID = Employee.employeeID " + 
						"INNER JOIN Campaign ON Campaign.campaignID = WorkDone.campaignID INNER JOIN Advert " +
						"ON Advert.campaignID = Campaign.campaignID WHERE Advert.form = 'radio');" ; 
		try
		{
			//create statements
			Statement s1 = con.createStatement();
			//run query and store results in result set
			ResultSet resSet = s1.executeQuery(query);
			//clear table
			tableResults.clearTable();
			//display in text area
		   	outputArea.setText("");
			while(resSet.next() ) {
				outputArea.append("ID: ");
			    outputArea.append(resSet.getString(1));
			    outputArea.append ("| Name: ");
			    outputArea.append(resSet.getString(2));
			    outputArea.append (" ");
			    outputArea.append(resSet.getString(3));  //year only
			    outputArea.append("\n");
			 }
			
		}
		catch (SQLException e){
			outputArea.setText(e.getMessage());
		}
			
			
	}
	
	//Each client's list of different advert types they have been commissioned for
	public void process1() {

		//Create the different views for compiling the final query
		String view1 = "CREATE VIEW vRadioAdverts AS SELECT Client.clientID, COUNT(Advert.form) AS NumberOfRadioAdverts "
					+ 	"FROM Client INNER JOIN Campaign ON Campaign.clientID = Client.clientID INNER JOIN Advert "
					+ 	"ON Advert.campaignID = Campaign.campaignID WHERE Advert.form = 'radio' GROUP BY clientID "
					+ 	"ORDER BY clientID;";
		String view2 = 	"CREATE VIEW vTVAdverts AS SELECT Client.clientID, COUNT(Advert.form) AS NumberOfTVAdverts FROM Client "
					+ 	"INNER JOIN Campaign ON Campaign.clientID = Client.clientID INNER JOIN Advert "
					+ 	"ON Advert.campaignID = Campaign.campaignID WHERE Advert.form = 'TV' GROUP BY clientID "
					+ 	"ORDER BY clientID;";
		String view3 = 	"CREATE VIEW vMagAdverts AS SELECT Client.clientID, COUNT(Advert.form) AS NumberOfMagAdverts FROM Client "
					+ 	"INNER JOIN Campaign ON Campaign.clientID = Client.clientID INNER JOIN Advert "
					+ 	"ON Advert.campaignID = Campaign.campaignID WHERE Advert.form = 'mag' GROUP BY clientID "
					+ 	"ORDER BY clientID;";
		String view4 = 	"CREATE VIEW vWebAdverts AS SELECT Client.clientID, COUNT(Advert.form) AS NumberOfWebAdverts FROM Client "
					+ 	"INNER JOIN Campaign ON Campaign.clientID = Client.clientID INNER JOIN Advert "
					+ 	"ON Advert.campaignID = Campaign.campaignID WHERE Advert.form = 'web' GROUP BY clientID "
					+ 	"ORDER BY clientID;";
		String view5 = 	"CREATE VIEW vAdverts AS SELECT Client.clientID, vRadioAdverts.NumberOfRadioAdverts, "
					+ 	"vWebAdverts.NumberOfWebAdverts, vTVAdverts.NumberOfTVAdverts, vMagAdverts.NumberOfMagAdverts "
					+ 	"FROM Client LEFT JOIN vRadioAdverts ON vRadioAdverts.clientID = Client.clientID LEFT JOIN vWebAdverts "
					+ 	"ON vWebAdverts.clientID = Client.clientID LEFT JOIN vTVAdverts ON vTVAdverts.clientID = Client.clientID "
					+ 	"LEFT JOIN vMagAdverts ON vMagAdverts.clientID = Client.clientID GROUP BY clientID ORDER BY clientID;";
		//Make the query
		String query = "SELECT * FROM vAdverts;";
		//Drop the tables for the next time run
		String drop1 = "DROP VIEW vRadioAdverts;";
		String drop2 = "DROP VIEW vWebAdverts;";
		String drop3 = "DROP VIEW vTVAdverts;";
		String drop4 = "DROP VIEW vMagAdverts;";
		String drop5 = "DROP VIEW vAdverts;";


		try
		{
			//Execute the code in order
			Statement s1 = con.createStatement();
			s1.executeUpdate(view1);
			s1.executeUpdate(view2);
			s1.executeUpdate(view3);
			s1.executeUpdate(view4);
			s1.executeUpdate(view5);
			//Create a results variable
			ResultSet resSet = s1.executeQuery(query);
			Statement s2 = con.createStatement();
			s2.executeUpdate(drop1);
			s2.executeUpdate(drop2);
			s2.executeUpdate(drop3);
			s2.executeUpdate(drop4);
			s2.executeUpdate(drop5);

			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");
			
		   	//Display the results
			while(resSet.next() ) {
			    outputArea.append ("Cient ID: ");
			    outputArea.append(resSet.getString(1));
			    outputArea.append ("| Radio ads: ");
			    outputArea.append(resSet.getString(2));
			    outputArea.append ("| WEb ads: ");
			    outputArea.append(resSet.getString(3));
			    outputArea.append ("| TV ads: ");
			    outputArea.append(resSet.getString(4));
			    outputArea.append ("| Magazine ads: ");
			    outputArea.append(resSet.getString(5));
			    outputArea.append("\n");
			}
		}
		catch (SQLException e)
		{
			outputArea.setText(e.getMessage());
		}
			
	}
	
	public void process2() {
		//Create a query
		String query = 	"SELECT ID AS EmployeeID, PersonalInfo.firstName,PersonalInfo.secondName, MAX(hours) AS MaxHoursWorked "
							+	"FROM (SELECT  WorkDone.employeeID AS ID, SUM(WorkDone.hoursWorked) as hours "
							+	"FROM WorkDone GROUP BY WorkDone.employeeID) WorkDone "
							+	"INNER JOIN Employee ON Employee.employeeID = ID "
							+	"INNER JOIN PersonalInfo ON PersonalInfo.personID = Employee.personID;";
		
		try
		{
			//Create the statement
			Statement s1 = con.createStatement();
			//Contain results in variable
			ResultSet resSet = s1.executeQuery(query);
			//Clear the table
			tableResults.clearTable();
		   	//Display the results
		   	outputArea.setText("");
			while(resSet.next() ) {
			    outputArea.append ("ID: ");
			    outputArea.append(resSet.getString(1));
			    outputArea.append ("| Name: '");
			    outputArea.append(resSet.getString(2));
			    outputArea.append (" ");
			    outputArea.append(resSet.getString(3));
			    outputArea.append ("'| Hours worked: ");
			    outputArea.append(resSet.getString(4));
			    outputArea.append("\n");
			}
		}
		catch (SQLException e)
		{
			outputArea.setText(e.getMessage());
		}
	}
	
	public void process3() {
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

		   	//Create the statement
		   	Statement stmt = con.createStatement();
			//Create the query
			String updateQuery = 	"UPDATE Invoice INNER JOIN ("
								+	"SELECT  WorkDone.campaignID AS ID, SUM(WorkDone.hoursWorked)*20 AS newCost "
								+	"FROM WorkDone GROUP BY WorkDone.campaignID) AS Costs ON ID = Invoice.campaignID " 
								+	"SET Invoice.cost = newCost WHERE Invoice.campaignID = ID;";
			//run update and get how many rows affected
			String newQuery = "SELECT * FROM Invoice;";
			int howManyRowsUpdated = stmt.executeUpdate(updateQuery);
			ResultSet resSet = stmt.executeQuery(newQuery);
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Invoice ID: ");
			    outputArea.append(resSet.getString(1));
			    outputArea.append ("| campaign ID: ");
			    outputArea.append(resSet.getString(2));
			    outputArea.append ("| Client ID: ");
			    outputArea.append(resSet.getString(3));
			    outputArea.append ("| Cost: ");
			    outputArea.append(resSet.getString(4));
			    outputArea.append("\n");
			 }
			
			
			outputArea.append("Rows updated = " + howManyRowsUpdated + "\n");
			//Clear the table
			tableResults.clearTable();
		}
		catch (SQLException e){
			outputArea.setText(e.getMessage());
		}
	}
	
	/*Corbin Beaumont, Query 1, Calculates average cost of all campaigns for clients who have clientID beginning with 1.*/
	public void process4() {

		//Create the query
		String query = "SELECT clientID, avg(cost) FROM Invoice GROUP BY clientID HAVING clientID LIKE '1%';";
		
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

		   	//Create a statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Client ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Average Cost: ");
			    outputArea.append(resSet.getString(2));
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();

		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
	
	/*Corbin Beaumont, Query 2, calculates the earnings per hour worked and groups it by campaign ID*/
	public void process5() 
	{
		//Create the query
		String query = 	"SELECT Invoice.campaignID, sum(Invoice.cost) DIV sum(WorkDone.hoursworked) AS averageCostPerHour "
					+	"FROM Invoice INNER JOIN WorkDone  ON Invoice.campaignID = WorkDone.campaignID "
					+	"GROUP BY Invoice.campaignID;";
		
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

		   	//Create the statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Campaign ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Earnings Per Hour: ");
			    outputArea.append(resSet.getString(2));
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();

		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
	
	/* Philip Lawson, Query 1, Employees that aren't working more than 10 hours on a project*/
	public void process6() 
	{
		//Create the query
		String query = 	"SELECT DISTINCT Employee.employeeID, PersonalInfo.firstName, PersonalInfo.secondName "
					+	"FROM PersonalInfo INNER JOIN Employee ON Employee.personID = PersonalInfo.personID "
					+	"WHERE Employee.employeeID NOT IN (SELECT DISTINCT Employee.employeeID FROM Employee "
					+	"INNER JOIN WorkDone on WorkDone.employeeID = Employee.employeeID "
					+	"WHERE WorkDone.hoursWorked > 10) ORDER BY Employee.employeeID;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

		   	//Create the statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Employee ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Name: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append(" ");
			    outputArea.append(resSet.getString(3));
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}

	/* Philip Lawson, Query 2, View that displays a list of employee ID's and their first and last names*/
	public void process7() 
	{
		//Create the drop command
		String drop = "DROP VIEW vEmployeeID;";
	   	//Create the view
		String view = "CREATE VIEW vEmployeeID AS SELECT Employee.EmployeeID, PersonalInfo.firstName, PersonalInfo.secondName "
					+	"FROM PersonalInfo INNER JOIN Employee ON Employee.personID = PersonalInfo.personID;"; 
		//Create the query 		
		String query = 	"SELECT vEmployeeID.EmployeeID, vEmployeeID.firstName, vEmployeeID.secondName FROM vEmployeeID;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

			//Create the statement
			Statement st = con.createStatement();
			//Execute the view
			st.executeUpdate(view);
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			//Execute the drop
			st.executeUpdate(drop);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Employee ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Name: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append(" ");
			    outputArea.append(resSet.getString(3));
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
	
	/* Oliver Brotchie Query 1, All middle managers (Anyone who is a manager but also has their own manager) */
	public void process8() 
	{
		//Create the query
		String query = 	"SELECT * FROM Employee WHERE Employee.employeeID IN ("
					+	"SELECT Employee.ManagerID FROM Employee) AND Employee.managerID IS NOT NULL;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

			//Create the statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Employee ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Person ID: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append("| Manager ID: ");
			    outputArea.append(resSet.getString(4));
				outputArea.append("| Email: ");
			    outputArea.append(resSet.getString(3));		    
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
	/* Oliver Brotchie, Query 2, Find all adverts that have a target demographic that aplies to 16 - 30 year olds */
	public void process9() 
	{
		//Create the query
		String query =	"SELECT * FROM Web WHERE Web.advertID IN (SELECT Web.advertID "
					+	"FROM (SELECT SUBSTRING_INDEX(Web.demographic, '>', -1) AS GTValue, Web.advertID AS GTID "
					+	"FROM Web WHERE Web.demographic LIKE '>%') AS GTQuery INNER JOIN Web ON Web.advertID = GTID "
					+	"WHERE CONVERT(GTValue,UNSIGNED INTEGER) <= 30) OR Web.advertID IN (SELECT Web.advertID "
					+ 	"FROM (SELECT SUBSTRING_INDEX(Web.demographic, '<', -1) AS LTValue, Web.advertID AS LTID "
					+ 	"FROM Web WHERE Web.demographic LIKE '<%') AS LTQuery INNER JOIN Web ON Web.advertID = LTID "
					+ 	"WHERE CONVERT(LTValue,UNSIGNED INTEGER) >= 30 AND CONVERT(LTValue,UNSIGNED INTEGER) >= 16) "
					+ 	"OR Web.advertID IN (SELECT Web.advertID FROM (SELECT SUBSTRING_INDEX(Web.demographic, '-', 1) "
					+ 	"AS ToLValue ,SUBSTRING_INDEX(Web.demographic, '-', -1) AS ToRValue, Web.advertID AS ToID "
					+ 	"FROM Web WHERE Web.demographic LIKE '%-%') AS ToQuery INNER JOIN Web ON Web.advertID = ToID "
					+ 	"WHERE CONVERT(ToLValue,UNSIGNED INTEGER) <= 16 AND CONVERT(ToRValue,UNSIGNED INTEGER) >= 30);";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

			//Create the statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Advert ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Region: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append("| Demographic: ");
			    outputArea.append(resSet.getString(3));
				outputArea.append("| Views: ");
			    outputArea.append(resSet.getString(4));
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
	/* Cameron Bone, Query 1, Displays a view of number of Employees who worked on each Campaign and the cost of each campaign*/
	public void process10() 
	{
		//Create the drop
		String drop = "DROP VIEW vHours;";
		//Create the view
		String view = "CREATE VIEW vHours AS SELECT Campaign.campaignID, Invoice.cost, COUNT(WorkDone.employeeID) "
					+ 	"AS NumberOfEmployees FROM Employee INNER JOIN WorkDone ON WorkDone.employeeID = Employee.employeeID "
					+ 	"INNER JOIN Campaign ON Campaign.campaignID = WorkDone.campaignID INNER JOIN Invoice "
					+ 	"ON Invoice.campaignID = Campaign.campaignID GROUP BY Campaign.campaignID;"; 
		//Create the query
		String query = 	"SELECT vHours.campaignID, vHours.cost, vHours.NumberOfEmployees FROM vHours;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");
			//Create the statement
			Statement st = con.createStatement();
			//Execute the view
			st.executeUpdate(view);
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			//Execute the drop
			st.executeUpdate(drop);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Campaign ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Cost: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append("| Number of Employees: ");
			    outputArea.append(resSet.getString(3));
			    outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
		}
		catch (SQLException e) {
				outputArea.setText(e.getMessage());
		}
	}
	/* Cameron Bone, Query 2, Finds the campaigns which have a TV or Radio advert which has a runtime longer than 40 seconds */
	public void process11() 
	{
		//Create the query
		String query = 	"SELECT Campaign.clientID, AVG(TVRadio.runTime) AS Average_Runtime FROM TVRadio INNER JOIN Advert "
					+ 	"ON Advert.advertID = TVRadio.advertID INNER JOIN Campaign  ON Campaign.campaignID = Advert.campaignID  "
					+ 	"GROUP BY Campaign.clientID HAVING Average_Runtime > 40;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

			//Create the statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Client ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Runtime: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}

	/* James Mullan, Query 1, Shows the Number of Employees involved in an advert in each region */
	public void process12() 
	{
		//Create the query
		String query = 	"SELECT Campaign.campaignID, Advert.advertID, Web.region, COUNT(WorkDone.employeeID) "
					+ 	"AS NumberOfEmployees FROM Employee INNER JOIN WorkDone ON WorkDone.employeeID = Employee.employeeID "
					+ 	"INNER JOIN Campaign ON Campaign.campaignID = WorkDone.campaignID INNER JOIN Advert "
					+ 	"ON Advert.campaignID = Campaign.campaignID INNER JOIN Web ON Web.advertID = Advert.advertID GROUP "
					+ 	"BY Web.region;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

			//Create the statement
			Statement st = con.createStatement();
			//Store the results
			ResultSet resSet = st.executeQuery(query);
					
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Campaign ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("| Advert ID: ");
			    outputArea.append(resSet.getString(2));
				outputArea.append("| Region: ");
			    outputArea.append(resSet.getString(3));
				outputArea.append("| Number of employees: ");
			    outputArea.append(resSet.getString(4));
				outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
	
	/* James Mullan, Query 2, Shows campaigns that do not possess a web advertisement*/
	public void process13() 
	{
		//Create the drop
		String drop = "DROP VIEW vWeb;";
		//Create the view
		String view = "CREATE VIEW vWeb AS SELECT DISTINCT Campaign.campaignID FROM Campaign INNER JOIN Advert "
					+ 	"ON Advert.campaignID = Campaign.campaignID WHERE Advert.form = 'web' ORDER BY Campaign.campaignID;"; 
		//Create the query
		String query = 	"SELECT DISTINCT Campaign.campaignID FROM Campaign LEFT JOIN vWeb "
					+ 	"ON vWeb.campaignID = Campaign.campaignID WHERE vWeb.campaignID IS NULL;";
	
		try {
			//Clear the table
			tableResults.clearTable();
		   	outputArea.setText("");

			//Create the statement
			Statement st = con.createStatement();
			//Execute the view
			st.executeUpdate(view);
			//Store the results
			ResultSet resSet = st.executeQuery(query);
			//Execute the drop
			st.executeUpdate(drop);
			
		   	//Display the results
			while(resSet.next() ) {
				outputArea.append("Campaign ID: ");
			    outputArea.append(resSet.getString(1));
				outputArea.append("\n");
			 }
			
			//Clear the table
			tableResults.clearTable();
	
		}
		catch (SQLException e) {
			outputArea.setText(e.getMessage());
		}
	}
}