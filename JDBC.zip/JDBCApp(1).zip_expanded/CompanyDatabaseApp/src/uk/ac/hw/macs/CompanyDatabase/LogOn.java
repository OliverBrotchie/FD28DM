package uk.ac.hw.macs.CompanyDatabase;


class LogOn
{
	private String username;
	private String password;

	
	public LogOn(String u, String p)
	{
		username = u;
		password = p;
	}
	
	public String getUName()
	{
		return username;
	}
	
	public String getPWord()
	{
		return password;
	}
	

}
	
	